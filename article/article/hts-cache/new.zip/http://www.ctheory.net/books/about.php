<!doctype html>
<html lang="en">

	<head>
		<meta charset="utf-8"/>
		<title>CTheory Books</title> <!-- Should read CTheory Books: booktitle, category, about, or other appropriate -->
	
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
        Remove this if you use the .htaccess -->
  		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  		<!-- Place favicon.ico & apple-touch-icon.png in the root of your domain and delete these references -->
  		<link rel="shortcut icon" href="./favicon.ico">
  		<link rel="apple-touch-icon" href="./favicon.png?v=2">
		

		<link rel="stylesheet" media="screen" href="./less/less.css"/>
				<meta name="apple-mobile-web-app-status-bar-style" content="translucent-black" />
		<meta name="apple-mobile-web-app-capable" content="yes" />

		<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1; user-scalable=no" />
		
		<!-- Added "maximum-scale=1" to fix the Mobile Safari auto-zoom bug on orientation changes, 
			but it will disable user-zooming completely. Bad for accessibility. -->

		
		<script type="application/x-javascript">
			addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);

			function hideURLbar(){
				window.scrollTo(0,1);
			}
			
			
			
			
			
		</script>
		
		<script type="text/javascript" >
		
			function updateCategoryView(cat)
			{
			 	t = cat;    		  
    		  	
    		  	window.location.href = "booklist.php?category="+t;
    		  	
			}

		
		</script>
		<!-- fixes some scrolly issues with iOS devices -->
			
		
	</head>

	<body>
	
	<header><a href="./index.php"><img class="logo" src="biglogo.png" alt="CTheory Books: the digital publisher"></a></header>
						
		
		<nav class="catSelect" >
		<select name="Book Categories" id="categories">
				<option>Book Series...</option> <!-- should a href="#", shouldn't do anything -->
				<option>All Categories</option>
				<option>Critical Digital Studies</option>
				<option>Politics and Culture</option>
				<option>New Media Aesthetics</option>
				<option>Theories of the Body</option>
				<option>The Canadian Series</option>		
		</select>
				<ul class="taskMenu">
		<a href="booklist.php"><li class="topMenu">Book Series
										<ul class="subMenu"><li><a href='javascript:updateCategoryView("Critical Digital Studies")'> Critical Digital Studies</a></li><li><a href='javascript:updateCategoryView("Politics and Culture")'>Politics and Culture</a></li><li><a href='javascript:updateCategoryView("New Media Aesthetics")'>New Media Aesthetics</a></li><li><a href='javascript:updateCategoryView("Theories of the Body")'>Theories of the Body</a></li><li><a href='javascript:updateCategoryView("The Canadian Series")'>The Canadian Series</a></li></ul>
								  </li></a>
		<a href="http://ctheory.net/library/journal.asp"><li class="topMenu">Digital Library</li></a>
		<a href="http://ctheorymultimedia.cornell.edu/"><li class="topMenu">Multimedia</li></a>
		<a href="./about.php"><li class="lastTask topMenu">Copyright</li></a>
		
		</ul>
		</nav>

		
		<section class="details">
		<span class="detailedTitle"></span>
	<Br>
		
		<span class="detailedDesc">
		<h2>Copyright and Permissions</h2><Br><br>
		<p>(C) 2012 CTheory Books.  All rights reserved.</p>
		<br>
		<p>The titles available on the CTheory Books website are for individual use (peer-to-peer) only.
		All other organizations and individuals including publishers, editors and librarians must contact CTheory@uvic.ca for permission to reproduce work published on the CTheory Books website.</p>
		<br><br><hr><br><br>
		<p>CTheory Books represent an expanding international circle of theorists, writers, artists, and poets who explore forms of critical thinking that are historically engaged, politically critical and theoretically diverse. CTheory Books are read in over 100 countries, from every continent and region.</p>
		<img src="./map.png" class="readmap">
		<p>Print versions of selected titles are available in the USA by St. Martin's Press (Palgrave). Translations available in German (Passagen Verlag - XMedia), Italian (Apogeo), Japanese (Hosei University Press), Chinese (Science & Technology Hong Kong).</p>
		<br></span>
		
		</section>
		
		
	
		  
		<footer>
		Copyright CTheory.net 2012
		</footer>
	</body>
	
</html>
