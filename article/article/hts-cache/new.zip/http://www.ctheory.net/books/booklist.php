<!doctype html>
<html lang="en">

	<head>
		<meta charset="utf-8"/>
		<title>CTheory Books</title> <!-- Should read CTheory Books: booktitle, category, about, or other appropriate -->
		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
        Remove this if you use the .htaccess -->
  		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  		<!-- Place favicon.ico & apple-touch-icon.png in the root of your domain and delete these references -->
  		<link rel="shortcut icon" href="./favicon.ico">
  		<link rel="apple-touch-icon" href="./favicon.png?v=2">
		

		<link rel="stylesheet" media="screen" href="./less/less.css"/>
		
		<meta name="apple-mobile-web-app-status-bar-style" content="translucent-black" />
		<meta name="apple-mobile-web-app-capable" content="yes" />

		<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1; user-scalable=no" />
		
		<!-- Added "maximum-scale=1" to fix the Mobile Safari auto-zoom bug on orientation changes, 
			but it will disable user-zooming completely. Bad for accessibility. -->

		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<!-- the following script fixes transparent png issues in IE6 -->
		<script type="application/x-javascript"> 
			addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);

			function hideURLbar(){
				window.scrollTo(0,1);
			}
		</script>
		<script>
			var blank = new Image();
			 blank.src = 'less/blank.gif';
			 
			 $(document).ready(function() {
			   var badBrowser = (/MSIE ((5\.5)|6)/.test(navigator.userAgent) && navigator.platform == "Win32");
			   if (badBrowser) {
			     // get all pngs on page
			     $('img[src$=.png]').each(function() {
			       if (!this.complete) {
			         this.onload = function() { fixPng(this) };
			       } else {
			         fixPng(this);
			       }
			     });
			   }
			 });
			 
			 function fixPng(png) {
			   // get src
			   var src = png.src;
			   // set width and height
			   if (!png.style.width) { png.style.width = $(png).width(); }
			   if (!png.style.height) { png.style.height = $(png).height(); }
			   // replace by blank image
			   png.onload = function() { };
			   png.src = blank.src;
			   // set filter (display original image)
			   png.runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + src + "',sizingMethod='scale')";
			 }
		</script>
		
		<script type="application/x-javascript">
			
			
			addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);

			function hideURLbar(){
				window.scrollTo(0,1);
			}
			
			function downloadePub(src)
			{
				
			}
			
			function download(type, src, id)
			{
										
						window.location.href = "signin.php?fileid="+id;
						
						
					
								}
			
		</script>

		
		<!-- fixes some scrolly issues with iOS devices -->

		
		<script type="text/javascript">
	
		var t = ""; 
		
		function getUrlVars()
		{
   		 	var vars = [], hash;
    		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    		for(var i = 0; i < hashes.length; i++)
    		{
        		hash = hashes[i].split('=');
        		vars.push(hash[0]);
        		vars[hash[0]] = hash[1];
    		}
    		
    		return vars;
		}
		
		
		function updateCategoryView(cat)
		{
			 	t = cat;    		  
    		  	$(".listEntry").each(function(i, d){
    		  		
    		  		//alert("T = "+ t +" :: "+ $(d).attr("title"));
    		  		$('HR').hide();
    		  		if($(d).attr("title") != t)
    		  		{
    		  			$(d).fadeOut("slow");
    		  		}else
    		  		{
    		  			$(d).fadeIn("slow");
    		  		}
    		  	});
    		  	
		}
		
		
		
		$(document).ready(function() {
		
		var vars = getUrlVars();
		
		if(vars['category'] != null)
		{
			
			t = vars['category'];
			t = t.replace(/%20/g," ");
		
			//alert('t = '+t);
			$(".listEntry").each(function(i, d){
			
    		  		
    		  		if($(d).attr("title") != t)
    		  		{
    		  			$('HR').hide();
    		  			$(d).hide();
    		  		}else
    		  		{
    		  			$(d).fadeIn("slow");
    		  		}
    		  	});

		}
		
    		  $("#categories").change(function(){
    		  t = $(this).val();    		  
    		  
    		  if(t == "All Categories")
    		  {

    		  	$(".listEntry").each(function(i, d){
    		  		$(d).fadeIn("slow");
    		  	});
    		  	
    		  	return;	
    		  }	
    		  
    		  
    		  
    		  $(".listEntry").each(function(i, d){
    		  		    		    $('HR').hide();	  		
    		  		if($(d).attr("title") != t)
    		  		{
    		  			$(d).fadeOut("slow");
    		  		}else
    		  		{
    		  			$(d).fadeIn("slow");
    		  		}
    		  	});
    		  }) 	
    	
		});
		</script>

		
	</head>
	

	
	<body>
	
	<header><a href="./index.php"><img class="logo" src="biglogo.png" alt="CTheory Books: the digital publisher"></a></header>
		
<!-- ################################# START NAVIGATION ################################# -->
<!-- This portion is the same across all pages on site -->
		
		
		
		<nav class="catSelect" >
		<select name="Book Categories" id="categories">
				<option>Book Series...</option> <!-- should a href="#", shouldn't do anything -->
				<option>All Categories</option>
				<option>Critical Digital Studies</option>
				<option>Politics and Culture</option>
				<option>New Media Aesthetics</option>
				<option>Theories of the Body</option>
				<option>The Canadian Series</option>		
		</select>
				<ul class="taskMenu">
		<a href="booklist.php"><li class="topMenu">Book Series
										<ul class="subMenu"><li><a href='javascript:updateCategoryView("Critical Digital Studies")'> Critical Digital Studies</a></li><li><a href='javascript:updateCategoryView("Politics and Culture")'>Politics and Culture</a></li><li><a href='javascript:updateCategoryView("New Media Aesthetics")'>New Media Aesthetics</a></li><li><a href='javascript:updateCategoryView("Theories of the Body")'>Theories of the Body</a></li><li><a href='javascript:updateCategoryView("The Canadian Series")'>The Canadian Series</a></li></ul>
								  </li></a>
		<a href="http://ctheory.net/library/journal.asp"><li class="topMenu">Digital Library</li></a>
		<a href="http://ctheorymultimedia.cornell.edu/"><li class="topMenu">Multimedia</li></a>
		<a href="./about.php"><li class="lastTask topMenu">Copyright</li></a>
		
		</ul>
		</nav>

		
<!-- ################################# END NAVIGATION ################################# -->
		
		
		<section class="booklist">
		
	<!-- Add static book HTML here -->
	
	<p class='seriesTitle listEntry' title="Critical Digital Studies" >Critical Digital Studies</p>
<ul class="bookList"> 




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=22"><img src="book_images/book_LITW_cover.jpg" class="bookThumb" width=80 alt="Life in the Wires cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=22">Life in the Wires</a></span>
		
<span class="bookAuthor">Arthur and Marilouise Kroker, Editors</span>
		
<span class="bookShortDesc">Life in the Wires is about life today, from Al-Jazeera to eBay, from creatively understanding new media to analyzing how questions of gender, race, class and colonialism have been deeply transformed by networked society.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=22'">Details</button><button class="listButton downloadApple" onclick='download("ePub", "books/LifeintheWires.epub", "22")'>ePub</button></div>
</li>




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=23"><img src="book_images/willtotechnology.jpg" class="bookThumb" width=80 alt="The Will to Technology and the Culture of Nihilism cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=23">The Will to Technology and the Culture of Nihilism</a></span>
		
<span class="bookAuthor">Arthur Kroker</span>
		
<span class="bookShortDesc">The Will to Technology and the Culture of Nihilism is what happens when previously seperated worlds implode, when the embedded time of critical theory streams the hyper-space of the Net.. Digital dialectics as theorizing at the jagged speed of data.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=23'">Details</button></div>
</li>




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=1"><img src="book_images/covers/digiital_delirium.jpg" class="bookThumb" width=80 alt="Digital Delirium cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=1">Digital Delirium</a></span>
		
<span class="bookAuthor">Edited and introduced by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">Digital Delirium writes the new horizon of electronic culture. The latest addition to the CultureTexts Series.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=1'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/DIGITAL DELIRIUM.pdf", "1")'>PDF</button></div>
</li>




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=2"><img src="book_images/covers/hacking.jpg" class="bookThumb" width=80 alt="Hacking the Future cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=2">Hacking the Future</a></span>
		
<span class="bookAuthor">Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">Written in the shadows of the digital age, Hacking the Future tells the story of what happens to us when information technology escapes the high tech labs of Silicon Valley and invades the sites of everyday culture. Shopping the GAP, Branded Flesh, the World-Wide-Web Self: these are some of the survival tales of people who just want to feel again in a culture that is numbed and purified. The accompanying spoken word/music CD by the Krokers and composers Steve Gibson and David Kristian provides a sonic tour of our accelerated culture.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=2'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/HACKINGTHEFUTURE.pdf", "2")'>PDF</button></div>
</li>




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=3"><img src="book_images/covers/data_trash.jpg" class="bookThumb" width=80 alt="Data Trash cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=3">Data Trash</a></span>
		
<span class="bookAuthor">Arthur Kroker and Michael A. Weinstein</span>
		
<span class="bookShortDesc">"<i>When the shadows grow deeper, and skeletal hands pull the curtain closed, and the talking heads of CNN glow like gibbous moons in the corner, and the majordomo throws another Branch Davidian on the fire, then my choice is clear: I'll pull my collar up and hunker down under the rusty springs of the couch with another heaping helping of Data Trash.</i>" -- Bruce Sterling</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=3'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/DATA TRASH.pdf", "3")'>PDF</button></div>
</li>




<li class="listEntry" title="Critical Digital Studies" >
<a href="details.php?id=15"><img src="book_images/covers/technology_and_can.gif" class="bookThumb" width=80 alt="Technology and the Canadian Mind cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=15">Technology and the Canadian Mind</a></span>
		
<span class="bookAuthor">Arthur Kroker</span>
		
<span class="bookShortDesc">"<i>...an intellectual tour de force, written with enormous power and insight. Kroker has seized on what is unique and vital and has rendered the Canadian mind itself on a world stage.</i>" 
    -Abraham Rotstein</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=15'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Technology and the Canadian Mind.pdf", "15")'>PDF</button></div>
</li>
</ul><hr>
<p class='seriesTitle listEntry' title="Politics and Culture" >Politics and Culture</p>
<ul class="bookList"> 




<li class="listEntry" title="Politics and Culture" >
<a href="details.php?id=19"><img src="book_images/covers/left_behind.gif" class="bookThumb" width=80 alt="Left Behind cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=19">Left Behind</a></span>
		
<span class="bookAuthor">Stephen Pfohl</span>
		
<span class="bookShortDesc">America's vision of itself as a nation blessed by God has provided strong spiritual support for bold and world-changing innovations in the areas of technology, governance, business, communications, imprisonment, and warfare. But this same vision has also long helped America to keep from common sight and collective memory legacies of a far grimmer sort.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=19'">Details</button><button class="listButton downloadApple" onclick='download("ePub", "books/Left Behind.epub", "19")'>ePub</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Left Behind.pdf", "19")'>PDF</button></div>
</li>




<li class="listEntry" title="Politics and Culture" >
<a href="details.php?id=20"><img src="book_images/covers/born_again.gif" class="bookThumb" width=80 alt="Born Again Ideology cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=20">Born Again Ideology</a></span>
		
<span class="bookAuthor">Arthur Kroker</span>
		
<span class="bookShortDesc">City Upon a Hill, the American Dream, a sacred covenant--the United States has done that most elusive and perhaps ineffable of all things: wrapped together the language of god and technology into a powerful, adventurous political experiment which is "premodern" in its (religious) sensibility and "posthuman" in it (technological) enthusiasm.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=20'">Details</button><button class="listButton downloadApple" onclick='download("ePub", "books/Born Again Ideology.epub", "20")'>ePub</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Born Again Ideology.pdf", "20")'>PDF</button></div>
</li>




<li class="listEntry" title="Politics and Culture" >
<a href="details.php?id=10"><img src="book_images/ipcover.jpg" class="bookThumb" width=80 alt="Ideology and Power cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=10">Ideology and Power</a></span>
		
<span class="bookAuthor">Edited and introduced by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">Ideology and Power in the Age of Lenin in Ruins is written in the shadow of the fall of the Berlin Wall. Here, the meaning of power and ideology is finally thought with and against the shattered horizon of socialist and capitalist realism. Thinking anew the theory and practice of democratic politics, the essays put into question the meaning of ideology (as false consciousness) and the meaning of power (as seduction). On the question of ideology, political theorists, including Anthony Giddens, Jurgen Habermas, Claude Lefort and Zygmunt Bauman, challenge the privileging of ideology-critique in orthodox Marxism. This critical reinterpretation of ideology is then accelerated by a radical (Baudrillardian) rereading of the meaning of power as seduction. The book concludes with political analyses of demon politics in the post-Cold War era.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=10'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/IDEOLOGY AND POWER.pdf", "10")'>PDF</button></div>
</li>
</ul><hr>
<p class='seriesTitle listEntry' title="New Media Aesthetics" >New Media Aesthetics</p>
<ul class="bookList"> 




<li class="listEntry" title="New Media Aesthetics" >
<a href="details.php?id=4"><img src="book_images/covers/spasm.jpg" class="bookThumb" width=80 alt="Spasm cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=4">Spasm</a></span>
		
<span class="bookAuthor">Arthur Kroker</span>
		
<span class="bookShortDesc">A theory-fiction about the crash world of virtual reality, from the cold sex of Madonna Mutant, the pure sex of Michael Jackson and the dead sex of Elvis to the technological fetishes of Silicon Valley. Written from the perspectives of cultural politics, music, photography, cinema and cyber-machine art, Spasm explores the ecstasy and fadeout of wired culture. Here, we suddenly find ourselves the inhabitants of a glittering, but vaguely menacing, technological galaxy where the machines finally begin to speak. Spasm is a book/CD to take along with you on your hacker journey of the electronic frontier.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=4'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/SPASM.pdf", "4")'>PDF</button></div>
</li>




<li class="listEntry" title="New Media Aesthetics" >
<a href="details.php?id=12"><img src="book_images/covers/seduction.jpg" class="bookThumb" width=80 alt="Seduction cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=12">Seduction</a></span>
		
<span class="bookAuthor">Jean Baudrillard, translated by Brian Singer</span>
		
<span class="bookShortDesc">Seduction is Jean Baudrillard's most provocative book. Here, under the sign of seduction all modern theory is put into question. Seduction speaks of the sudden reversibility in the order of things where discourse is absorbed into its own signs without a trace of meaning. In the sudden triumph of seduction in apocalyptic culture there is also signaled the end of history. As Baudrillard says, "Nothing can be greater than seduction itself, not even the order that destroys it."</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=12'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/SEDUCTION.pdf", "12")'>PDF</button></div>
</li>




<li class="listEntry" title="New Media Aesthetics" >
<a href="details.php?id=11"><img src="book_images/covers/panic_encylopedia.jpg" class="bookThumb" width=80 alt="Panic Encyclopedia cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=11">Panic Encyclopedia</a></span>
		
<span class="bookAuthor">Arthur Kroker, Marilouise Kroker and David Cook</span>
		
<span class="bookShortDesc">In a stimulating and thoroughly entertaining look at the rapid countdown to the year 2000, the Panic Encyclopedia argues that in the postmodern era, science and technology are the real language of power, and illustrates the resulting culture through a post-alphabetical listing of "panics" - from Panic Art to Panic Zombies, and including Panic Elvis, Panic Psychoanalysis and Panic Sex. Humorously embracing newspaper and media events and philosophers from Hegel to McLuhan, the text chronicles the implosion of the modem world into a final singularity.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=11'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Panic Encyclopedia.pdf", "11")'>PDF</button></div>
</li>




<li class="listEntry" title="New Media Aesthetics" >
<a href="details.php?id=13"><img src="book_images/covers/pomo_scene.jpg" class="bookThumb" width=80 alt="The Postmodern Scene cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=13">The Postmodern Scene</a></span>
		
<span class="bookAuthor">Arthur Kroker and David Cook</span>
		
<span class="bookShortDesc"><i>The Postmodern Scene</i> is a series of major theorizations about key artistic and intellectual tendencies in the postmodern condition. A variety of texts, ranging from Nietzsche's <i>The Will to Power</i>, Serres' <i>Hermes</i>, Baudrillard's <i>Precession of Simulacra</i>, the visual art of Fischl, Hopper, Colville, and Magritte and recent performance art are used as probes of the human fate in the contemporary century. Here a theoretical reflection is viewed as a privileged artistic act: simultaneously a critical encounter with the "shock of the real" and a meditation in the form of a lament over the "intimations of deprival" which speak to us now of postmodern culture, art, and philosophy in ruins.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=13'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/THE POSTMODERN SCENE.pdf", "13")'>PDF</button></div>
</li>




<li class="listEntry" title="New Media Aesthetics" >
<a href="details.php?id=14"><img src="book_images/covers/life_after_pomo.jpg" class="bookThumb" width=80 alt="Life After Postmodernism cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=14">Life After Postmodernism</a></span>
		
<span class="bookAuthor">Edited and introduced by John Fekete</span>
		
<span class="bookShortDesc"><i>Life After Postmodernism</i> is a pioneering text on the question of value in the postmodern scene.  After a long hiatus in which discussions of value have been eclipsed by the death of the subject in post-structuralist theory, this collection of essays suggests that we are on the threshold of a new value debate in contemporary politics, aesthetics, and society. Rejecting the denial of value by Derrida and other representative of New French thought, this collection takes Nietzsche as its point of departure for putting evaluation back on the intellectual agenda and for a new synthesis -- hyper-pragmatism -- of liberalism and Marxism.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=14'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/LIFE AFTER POSTMODERNISM.pdf", "14")'>PDF</button></div>
</li>
</ul><hr>
<p class='seriesTitle listEntry' title="Theories of the Body" >Theories of the Body</p>
<ul class="bookList"> 




<li class="listEntry" title="Theories of the Body" >
<a href="details.php?id=7"><img src="book_images/covers/last_sex.jpg" class="bookThumb" width=80 alt="The Last Sex cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=7">The Last Sex</a></span>
		
<span class="bookAuthor">Edited and introduced by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">"<i>The Last Sex looks at the future of gender in an age when the transgendered have emerged as a walking and breathing challenge to old sex definitions. Both the Krokers and the authors included (Kathy Acker, Shannon Bell, Stephen Pfohl) present rallying cries for what the Krokers call "transgenic gender," a new gender that lies beyond our current ideas of sexuality, one that exists outside the dualistic man/woman model.</i>" - Richard Kadrey, Future Sex</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=7'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/The Last Sex.pdf", "7")'>PDF</button></div>
</li>




<li class="listEntry" title="Theories of the Body" >
<a href="details.php?id=5"><img src="book_images/covers/possessed_individual.jpg" class="bookThumb" width=80 alt="The Possessed Individual cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=5">The Possessed Individual</a></span>
		
<span class="bookAuthor">Arthur Kroker</span>
		
<span class="bookShortDesc">The Possessed Individual rubs North America against contemporary French thought. What results is a dramatic reinterpretation of French theory as a prophetic analysis of the speed-life of the twenty-first century, and a critical rethinking of the politics and culture of the technological dynamo. This book is a hinge between the mirror of seduction that is culture today and the philosophical ruptures of French thought, from Sartre and Camus to Baudrillard and Virilio. And why the fascination with French thought? Because this discourse is a theoretical foreground to the political background of America: fractal thinkers in whose central images one finds the key power configurations of the American hologram. Read the French, therefore, to learn a language for thinking anew the empire of technology.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=5'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/The Possessed Individual.pdf", "5")'>PDF</button></div>
</li>




<li class="listEntry" title="Theories of the Body" >
<a href="details.php?id=9"><img src="book_images/covers/hysterical.jpg" class="bookThumb" width=80 alt="The Hysterical Male cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=9">The Hysterical Male</a></span>
		
<span class="bookAuthor">Edited and introduced by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">A thematically focused exploration of feminism under the sign of male hystericization, critical feminists from Canada, the USA and Britain track the next stage of gender politics. What results is an intense provocative and creative theorization of feminism under the failing sign of the unitary male subject.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=9'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/THE HYSTERICAL MALE.pdf", "9")'>PDF</button></div>
</li>




<li class="listEntry" title="Theories of the Body" >
<a href="details.php?id=8"><img src="book_images/covers/Body_invaders.jpg" class="bookThumb" width=80 alt="Body Invaders cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=8">Body Invaders</a></span>
		
<span class="bookAuthor">Edited and introduced by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">Body Invaders explores the fate of the body in the postmodern condition. Introduced by theses on power and sexuality, it proceeds to analyze the key theoretical contributions of Bataille, Foucault, Baudrillard and Kristeva, and ranges widely over the suppressions and obsessions which mark theoretical discourse and public policy in relation to sexual eroticism, fashion, reproduction and bodily decay.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=8'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/BODY INVADERS.pdf", "8")'>PDF</button></div>
</li>




<li class="listEntry" title="Theories of the Body" >
<a href="details.php?id=24"><img src="book_images/covers/feminismnow.jpg" class="bookThumb" width=80 alt="Feminism Now cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=24">Feminism Now</a></span>
		
<span class="bookAuthor">Edited by Arthur and Marilouise Kroker</span>
		
<span class="bookShortDesc">Feminism Now is like Magritte’s brilliant depiction of blood from the head as rupture and transgression. <i>Memory</i>: that’s the radical promise of feminist critique which is, against the global, cultural amnesia of the modern century, the historical remembrance of <i>temps perdu</i> and of better possibilities not yet achieved. <i>Memory</i>, of both a past yet not written and of a future yet not dreamed, is the truly, and perhaps <i>only</i>, radical political terrain in postmodernism.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=24'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Feminism Now.pdf", "24")'>PDF</button></div>
</li>
</ul><hr>
<p class='seriesTitle listEntry' title="The Canadian Series" >The Canadian Series</p>
<ul class="bookList"> 




<li class="listEntry" title="The Canadian Series" >
<a href="details.php?id=16"><img src="book_images/covers/cb_mac.gif" class="bookThumb" width=80 alt="C.B. Macpherson cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=16">C.B. Macpherson</a></span>
		
<span class="bookAuthor">William Leiss</span>
		
<span class="bookShortDesc">Canada's preeminent political theorist, C.B. Macpherson won his international reputation for his controversial interpretations of liberalism. This book - the first to examine the entire range of his writings - seeks to place that interpretation of liberalism within the overall framework of his intellectual development. Focusing on two key themes - property and the state - C.B. Macpherson: Dilemmas of Liberalism and Socialism tracks Macpherson's analysis of the contradictions of liberal-democracy through all of his writings. More than a text on Macpherson, this book contains an explosive historical thesis: the notion of the quasi-market society as the common fate of contemporary capitalist and communist societies.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=16'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/Dilemmas of Liberalism and Socialism.pdf", "16")'>PDF</button></div>
</li>




<li class="listEntry" title="The Canadian Series" >
<a href="details.php?id=17"><img src="book_images/covers/culture_critique.jpg" class="bookThumb" width=80 alt="Culture Critique cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=17">Culture Critique</a></span>
		
<span class="bookAuthor">Michael A. Weinstein</span>
		
<span class="bookShortDesc">Culture Critique features the work of Quebec's key cultural theorist Fernand Dumont in a thorough exploration of the Québécois identity from the Quiet Revolution to the present.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=17'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/CULTURE CRITIQUE.pdf", "17")'>PDF</button></div>
</li>




<li class="listEntry" title="The Canadian Series" >
<a href="details.php?id=18"><img src="book_images/covers/vision_of_the_new.gif" class="bookThumb" width=80 alt="Northrop Frye cover"></a>
		
<span class="listing bookTitle"><a href="details.php?id=18">Northrop Frye</a></span>
		
<span class="bookAuthor">David Cook</span>
		
<span class="bookShortDesc">The bulk of Frye's writings deals with the tradition as it is given from the great writers of Europe; yet, his response to these writers has in an important way been fashioned by his own experience in North America and, more particularly, in Canada. Thus the main theme of this study is Northrop Frye's "America A Prophecy"; a vision of the New World.</span>
		
<div class="listButtonRow"><button class="listButton" onclick="window.location='./details.php?id=18'">Details</button><button class="listButton downloadPDF" onclick='download("PDF", "books/NORTHROP FRYE.pdf", "18")'>PDF</button></div>
</li></ul>


		</section>
		<p>
		
		  
		  
		<footer>
	 	Copyright CTheory.net 2012
		</footer>
	</body>
	
</html>
