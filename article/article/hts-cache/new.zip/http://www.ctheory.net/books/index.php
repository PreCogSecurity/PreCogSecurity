<!doctype html>
<html lang="en">

	<head>
		<meta content="text/html" charset="utf-8"/>
		<title>CTheory Books</title>
	
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
        Remove this if you use the .htaccess -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta name="apple-mobile-web-app-status-bar-style" content="translucent-black" />
		<meta name="apple-mobile-web-app-capable" content="yes" />
	
		<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1; user-scalable=no">
		
		<!-- Place favicon.ico & apple-touch-icon.png in the root of your domain and delete these references -->
  		<link rel="shortcut icon" href="./favicon.ico">
  		<link rel="apple-touch-icon" href="./favicon.png?v=2">
		<link rel="stylesheet" media="screen" href="./less/less.css">
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<!-- Add "maximum-scale=1" to fix the Mobile Safari auto-zoom bug on orientation changes, 
			but keep in mind that it will disable user-zooming completely. Bad for accessibility. -->

		<!-- <script src="less/less-grid.js"></script> -->
		<!-- the following script fixes transparent png issues in IE6 -->
		<script type="application/x-javascript"> 
			addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);

			function hideURLbar(){
				window.scrollTo(0,1);
			}
		</script>
		<script>
			var blank = new Image();
			 blank.src = 'less/blank.gif';
			 
			 $(document).ready(function() {
			   var badBrowser = (/MSIE ((5\.5)|6)/.test(navigator.userAgent) && navigator.platform == "Win32");
			   if (badBrowser) {
			     // get all pngs on page
			     $('img[src$=.png]').each(function() {
			       if (!this.complete) {
			         this.onload = function() { fixPng(this) };
			       } else {
			         fixPng(this);
			       }
			     });
			   }
			 });
			 
			 function fixPng(png) {
			   // get src
			   var src = png.src;
			   // set width and height
			   if (!png.style.width) { png.style.width = $(png).width(); }
			   if (!png.style.height) { png.style.height = $(png).height(); }
			   // replace by blank image
			   png.onload = function() { };
			   png.src = blank.src;
			   // set filter (display original image)
			   png.runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + src + "',sizingMethod='scale')";
		 }
		</script>
		
	</head>

	<body>
	
	<header><a href="./index.php"><img class="logo" src="biglogo.png" alt="CTheory Books: the digital publisher"></a></header>
		
		<section class="frontnav">
		
		<div class="frontBooks" id="books"><b><a href="booklist.php">books</a></b>
		
		<p class="frontdesc">A pioneering series of titles exploring and challenging received discourses in political and social theory, the body, science and technology, art, and critical aesthetics.</p>
		</div>
		
		<div class="frontLibrary" id="library"><b><a href="http://ctheory.net/library/default.asp">digital library</a></b>
		<p class="frontdesc">Archive of the <i>Canadian Journal of Political and Social Theory</i> (1976 - 91). A peer-reviewed independent journal of critical thought, CJPST is the intellectual foundation of <i>CTheory</i>.</p>
		</div>
		
		<div class="frontMultimedia" id="multimedia"><b><a href="http://ctheorymultimedia.cornell.edu/">multimedia</a></b>
		<p class="frontdesc">Web media produced by an active collection of digital artists, designers and theorists organized and developed with Cornell Univeristy Library.</p>
		</div>
		
		<div class="frontAbout" id="about"><b><a href="about.php">copyright</a></b>
		<p class="frontdesc">(C) 2012 CTheory Books. All rights reserved. The titles available on the CTheory Books website are for individual use (peer-to-peer) only.</p>
		</div>
		</section>
	
		<footer>
		Copyright CTheory.net 2012
		</footer>
	</body>
	
</html>
